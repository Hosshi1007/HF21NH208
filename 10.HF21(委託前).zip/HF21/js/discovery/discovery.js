/*切り替え時の写真リロード*/
function reload() {
	window.location.reload();
}

///*特定のクラスを持つ要素を取得し、それに対してJavaScriptを実行する例*/
//const elements = document.querySelectorAll('.content1');
//
//elements.forEach(element => {
//	/*iOS用スクロールロック*/
//	function disableScroll(event) {
//		event.preventDefault();
//	}
//	// イベントと関数を紐付け
//	document.addEventListener('touchmove', disableScroll, { passive: false });
//});
