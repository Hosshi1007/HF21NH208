/* ------------------------------------------スワイプ削除-------------------------------------  */

var tsJqSwipeX = -1; // X軸のスワイプ位置の初期値
var tsJqSwipeY = -1; // Y軸のスワイプ位置の初期値

$(function swipedelete() {
	// タッチが開始されたときの処理
	$(document).on("touchstart", ".swipe-item", function (event) {
		tsJqSwipeX = event.changedTouches[0].pageX; // X軸のタッチ位置を保存
		tsJqSwipeY = event.changedTouches[0].pageY; // Y軸のタッチ位置を保存
	});
	// タッチが終了したときの処理
	$(document).on("touchend", ".swipe-item", function (event) {
		tsJqSwipeX = -1; // X軸のスワイプ位置をリセット
	});
	// タッチ移動中の処理
	$(document).on("touchmove", ".swipe-item", function (event) {
		if (Math.abs(event.changedTouches[0].pageY - tsJqSwipeY) > 10) // Y軸方向の移動が10ピクセル以上ならX軸のスワイプ位置をリセット
			tsJqSwipeX = -1;
		if (tsJqSwipeX != -1 && Math.abs(event.changedTouches[0].pageX - tsJqSwipeX) > 35) { // X軸のスワイプ位置が記録されていて、35ピクセル以上移動した場合
			tsJqSwipeX = -1; // X軸のスワイプ位置をリセット
			
			// スワイプされた時の処理
//			$(this).css("background-color", "#cd0000"); // 背景色を変更
			$(this).slideUp("slow"); // スライドアップさせる
			
			loadContent();
		}
	})
})

/* ------------------------------------------呼び出し用関数-------------------------------------  */

const maincontent = document.querySelectorAll('.maincontent');

const posts = document.querySelectorAll('.slyd');
let i = 0;
const max = 1000;  //最大表示可能コンテンツ数
const loadBatchSize = 8; //１回の読み込みで追加するコンテンツ量

let hitflag = 0;

// loadContent関数
const loadContent = async () => {
	for (let j = 0; j < loadBatchSize; j++) {
		// posts.insertAdjacentHTML('beforeend','<div id="post" class="loading" style="margin-bottom:70px"><div class="spinner-box"><div class="circle-border"><div class="circle-core"></div></div></div></div>');
		const response = await fetchdata(); //response変数にデータをフェッチ
		const newest = await response.text(); //後にコンテンツが最新か比較するための変数

		var postElement = document.querySelector('#post.loading');//データ読み込み終了時
		//読み込み中 == trueの場合
		if (postElement && j == 0) {//数個一気に読み込むが、1つ目のときだけ500msディレイ
		    await new Promise(resolve => setTimeout(resolve, 500));//解決までに500msセルフディレイ
		    postElement.remove();  //ロードアニメーション削除
		}
		else if(postElement){//２個め以降はすぐに解決
			postElement.remove();
		}
		// コンテンツをHTMLに追加
		for (const postElement of posts) {
			// HTML追加
			postElement.insertAdjacentHTML('beforeend', await response.text());// 追加HTML
    
			// 追加した要素を取得
			//const addedElement = postElement.lastElementChild; // 最後に追加された要素を取得する（追加したHTMLに対応する要素）
			const addedElement1 = postElement.querySelector("div.maincontent");
			const addedElement2 = postElement.querySelector(".slyd");

			// 追加した要素にスタイルを適用する
			if (addedElement1) {
				console.log("addedElement1=true");
				addedElement1.style.height = 'calc(100% - 21px - 20px)';
			}
			if (addedElement2) {
				console.log("addedElement2=true");
				addedElement2.style.height = 'calc(100% - 21px - 20px)';
			}
		}
		i++;
		if (newest === '<div id="post" class="newest">おすすめのコンテンツは以上です。</div>' || newest === '<div id="post" class="newest">データの取得中にエラーが発生しました。</div>') {
			i = max;
			return;
		}
	}
};