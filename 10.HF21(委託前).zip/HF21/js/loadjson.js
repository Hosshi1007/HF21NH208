function loadJsonData() {
  // fetchを使用してJSONデータを取得
  fetch('wave.json')
    .then(response => response.json())
    .then(jsonData => {
      // コンソールログでJSONデータを確認
      console.log('JSONデータ:', jsonData);

      // 特定の値を取得する例
      let test = jsonData[0];
      let test2 = jsonData[0].waveID;
      console.log(test);
      console.log(test2);

      //ここから繰り返し処理して上から10件表示する

      for(var i=0; i<60; i++){
    	//時間差を計算
          var calresult = caltime(jsonData[i].posttime);

          // JSONデータを表示するHTMLを構築
          document.querySelectorAll('.content1 .userid')[i].innerText = "@"+jsonData[i].userid;
          document.querySelectorAll('.content1 .username')[i].innerText = jsonData[i].username;
          document.querySelectorAll('.content1 .maru')[i].src = jsonData[i].user_img;

          if (jsonData[i].imgID1 === "none") {
        	  document.querySelectorAll('.content1 .zoom')[4 * i ].style.display = "none";
          } else {
        	  document.querySelectorAll('.content1 .zoom')[4 * i ].src = jsonData[i].imgID1;
          }

          if (jsonData[i].imgID2 === "none") {
        	  document.querySelectorAll('.content1 .zoom')[4 * i + 1].style.display = "none";
          } else {
        	  document.querySelectorAll('.content1 .zoom')[4 * i + 1].src = jsonData[i].imgID2;
          }

          if (jsonData[i].imgID3 === "none") {
        	  document.querySelectorAll('.content1 .zoom')[4 * i + 2].style.display = "none";
          } else {
        	  document.querySelectorAll('.content1 .zoom')[4 * i + 2].src = jsonData[i].imgID3;
          }

          if (jsonData[i].imgID4 === "none") {
        	  document.querySelectorAll('.content1 .zoom')[4 * i + 3].style.display = "none";
          } else {
        	  document.querySelectorAll('.content1 .zoom')[4 * i + 3].src = jsonData[i].imgID4;
          }

          if(jsonData[i].imgID1 === "none" && jsonData[i].imgID2 === "none" && jsonData[i].imgID3 === "none" &&jsonData[i].imgID4 === "none"){
        	  document.querySelectorAll('.content1 .main_contents_contents_image')[i].style.display = "none";
          }

          document.querySelectorAll('.y')[i].setAttribute('onclick', 'redirectToWave(' + jsonData[i].waveID +  ')');
          document.querySelectorAll('.content1 .maincontent')[i].innerText = jsonData[i].maincontent;
          document.querySelectorAll('.content1 .timesago')[i].innerText = calresult;
      }

    })
    .catch(error => console.error('ファイルの読み込み中にエラーが発生しました', error));
}


function caltime(inputDateTime) {
    // 日時文字列をDateオブジェクトに変換
    const targetDate = new Date(inputDateTime.replace(/-/g, '/'));

    // 現在時刻を取得
    const now = new Date();

    // 時差補正（日本の場合は9時間）
    const timeZoneOffset = 9 * 60 * 60 * 1000;
    const targetTime = targetDate.getTime() + timeZoneOffset;
    const currentTime = now.getTime() + timeZoneOffset;

    // 時差補正後の差を計算
    const timeDifference = currentTime - targetTime;

    // 差を秒単位に変換
    const secondsDifference = Math.floor(timeDifference / 1000);

    if (secondsDifference >= 24 * 60 * 60) {
        const days = Math.floor(secondsDifference / (24 * 60 * 60));
        return `･${days}日前`;
    } else if (secondsDifference >= 60 * 60) {
        const hours = Math.floor(secondsDifference / (60 * 60));
        return `･${hours}時間前`;
    } else if (secondsDifference >= 60) {
        const minutes = Math.floor(secondsDifference / 60);
        return `･${minutes}分前`;
    } else if (secondsDifference >= 0) {
        return `･${secondsDifference}秒前`;
    }else{
    	return `･future messege`;
    }
}
