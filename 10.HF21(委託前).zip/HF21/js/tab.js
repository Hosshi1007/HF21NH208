$('.tab-content>div').hide();
$('.tab-content>div').first().slideDown(0);
  $('.tab-buttons span').click(function(){
    var thisclass=$(this).attr('class');
    $('#lamp').removeClass().addClass('#lamp').addClass(thisclass);
    $('.tab-content>div').each(function(){
      if($(this).hasClass(thisclass)){
        $(this).fadeIn(0);
      }
      else{
        $(this).hide();
      }
    });
  });
// クリックでcontent1と2の表示を切り替える
document.getElementById('contents2').addEventListener('click', function() {
    document.getElementById('content1').style.display = 'none';
    document.getElementById('content2').style.display = 'block';
});
        document.getElementById('contents1').addEventListener('click', function() {
    document.getElementById('content2').style.display = 'none';
    document.getElementById('content1').style.display = 'block';
});