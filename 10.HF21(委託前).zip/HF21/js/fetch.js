let userdata = 0;
let images = new Array(4);
//*----------------------------------------------------------*loadjson()*----------------------------------------------------------*//
async function loadjson() {
  try {
    const response = await fetch('wave.json');
    const jsonData = await response.json();
    if(userdata < jsonData.length){
		let waveID = jsonData[userdata].waveID;//0
	    let username = jsonData[userdata].username;//1
	    let userid = jsonData[userdata].userid;//2
	    let usericon = jsonData[userdata].user_img;//3
	    let time = jsonData[userdata].time;//4
	    let maincontent = jsonData[userdata].maincontent;//5
		let imgID1 = jsonData[userdata].imgID1;//6
		let imgID2 = jsonData[userdata].imgID2;//7
		let imgID3 = jsonData[userdata].imgID3;//8
		let imgID4 = jsonData[userdata].imgID4;//9
		let posttime = jsonData[userdata].posttime;//10
	    let heart = jsonData[userdata].heart;//11
		let rewave = jsonData[userdata].rewave;//12
		let views = jsonData[userdata].views;//13
	    userdata++;
	    let error = 0;
	    return {waveID, username, userid, usericon, time, posttime, imgID1,imgID2,imgID3,imgID4,maincontent, heart, rewave, views, error};
    }
    else{
		let error = 1;
		return{error}
	}
  } catch (error) {
    console.error('ファイルの読み込み中にエラーが発生しました', error);
    throw error;
  }
}
//*----------------------------------------------------------*fetchdata*----------------------------------------------------------*//
let count = 1;
let dataArray = "";

window.fetchdata = async url => {
  try {
	let heartArray = ["heart","heart1","hearted"];
	let rewaveArray = ["rewave","rewave1","rewaved"];
	let heartStatus1 = heartArray[0];//heart初期状態
	let rewaveStatus1 = rewaveArray[0];//rewave初期状態
	let heartStatus2 = heartArray[1];//heart:hover状態
	let rewaveStatus2 = rewaveArray[1];//rewave:hover状態
    var jsonData = await loadjson();

    //フェッチエラーが起きていない場合データを取得する
    let error = jsonData.error;
    if (error == 0) {
			let waveID = jsonData.waveID;				//wave主キー取得
		    let username = jsonData.username;			//ユーザー名取得
	    let userid = jsonData.userid;				//ユーザーid取得
	    let usericon = jsonData.usericon;			//ユーザーiconディレクトリ取得
	    let time = jsonData.time;					//発信時間取得
	    let maincontent = jsonData.maincontent;		//メインコンテンツ取得
		let imgID1 = jsonData.imgID1;				//１枚目の画像取得
		let imgID2 = jsonData.imgID2;				//２枚目の画像取得
		let imgID3 = jsonData.imgID3;				//３枚目の画像取得
		let imgID4 = jsonData.imgID4;				//４枚目の画像取得
		let views = jsonData.views;
		//初回フェッチのみanalysisテーブルからデータを取得
		if (count == 1) {
		    try {
		        const data = await analysis();
		        dataArray = JSON.parse(data);
		        console.log(dataArray);
				for(let num=0; num<dataArray.length; num++){
					if(waveID == dataArray[num][0]){
						if(dataArray[num][1] == 1){
							heartStatus1 = heartArray[2];//フェッチ段階でいいね状態とする
						}
						else if(dataArray[num][1] == 0){
							heartStatus1 = heartArray[0];//フェッチ段階でいいねされていない状態とする
						}
						if(dataArray[num][2] == 1){
							rewaveStatus1 = rewaveArray[2];//フェッチ段階でリウェーヴ状態とする
						}
						else if(dataArray[num][2] == 0){
							rewaveStatus1 = rewaveArray[0];//フェッチ段階でリウェーヴされていない状態とする
						}
					}
				}
		    } catch (error) {
		        alert("アカウント情報が取得できませんでした。");
		    }
		}
				for(let num=0; num<dataArray.length; num++){
					if(waveID == dataArray[num][0]){
						if(dataArray[num][1] == 1){
							heartStatus1 = heartArray[2];//フェッチ段階でいいね状態とする
						}
						else if(dataArray[num][1] == 0){
							heartStatus1 = heartArray[0];//フェッチ段階でいいねされていない状態とする
						}
						if(dataArray[num][2] == 1){
							rewaveStatus1 = rewaveArray[2];//フェッチ段階でリウェーヴ状態とする
						}
						else if(dataArray[num][2] == 0){
							rewaveStatus1 = rewaveArray[0];//フェッチ段階でリウェーヴされていない状態とする
						}
					}
				}
		if(imgID1 != 'none'){
			images[0] =  '<div class="hsp3p"></div>' +
			'<div class="main_contents_contents_image">'+
			'<div class="main_contents_contents_image_box1">'+
			'<img src="'+imgID1+'" alt="image1" class="zoom">';//img1枚目がある場合
			if(imgID2 != 'none'){
				if(imgID3 == 'none'){
					images[1] =  '</div>'+
					'<div class="main_contents_contents_image_box2">'+
					'<img src="'+imgID2+'" alt="image2" class="zoom">'+
					'</div>'+
					'</div>';//3枚目がない場合
					images[2] = "";
					images[3] = "";
				}
					else{
						images[1] =  '<img src="'+imgID2+'" alt="image2" class="zoom">'
						+'</div>';//2枚目があり、3枚目がある場合
						if(imgID3 != 'none'){
							images[2] =  '<div class="main_contents_contents_image_box1">'+
										 '<img src="'+imgID3+'" alt="image3" class="zoom">';//img3枚目がある場合
						if(imgID4 != 'none'){
							images[3] =  '<img src="'+imgID4+'" alt="image4" class="zoom">'+
											'</div>'+
											'</div>';//img4枚目がある場合
						}
						else{
							images[3] = '</div>'+
										'</div>';//img4枚目がない場合
						}
					}
				}
			}
			else{
				images[1] = '</div>'+
							'</div>'; //img2枚目がない場合
				images[2] = '';
				images[3] = '';

			}
		}
		else{
			images[0] = '';//img1枚目がない場合
			images[1] = '';
			images[2] = '';
			images[3] = '';
		}
		let posttime = jsonData.posttime;			//ポスト時間を取得
	    let heart = jsonData.heart;					//いいね数取得
		let rewave = jsonData.rewave;				//リウェーブ数取得
	    let content = 								//コンテンツ内容定義
	      '<div id="post" class="U70U6FU73U74">' +
	      '<div class="wr5TIPcMoO">'+
	      '<div class="kOI6nTrabP">'+
	      '<div class="vwSl7PQK7o">'+
	      '<div class="hsp12p"></div>' +
	      '<div class="xyz">' +
	      '<div class="picture"><img class="maru" src="'+ usericon +'" alt="picture"><div class="dwa"></div></div>' +
	      '<div class="y">' +
	      '<div class="z">' +
	      '<div class="username">' + username + '</div>' +
	      '<div class="userid">@'+ userid +'</div>' +
	      '<div class="timesago">·'+ time +'</div>' +
	      '<div class="postindm"><img class="postindm" alt="dm" width="20px" height="20px" src="/HF21/image/menu14.png"></div>' +
	      '</div>' +
	      '<div class="hsp3p"></div>' +
	      '<div class="maincontent">'+ maincontent +'</div>' +
		  images[0]+
		  images[1]+
		  images[2]+
		  images[3]+
	      '<div class="hsp6p"></div>' +
	      '<div class="hasamu">'+
	      //リウェーブ
	      '<div id="rewave'+waveID+'" class="icons" onclick="incrementRewaveCount('+waveID+')"><div class="rewave"><img height="20px" width="20px" src="image/'+rewaveStatus1+'.svg" alt="img"><img class="image-b" height="20px" width="20px" src="image/'+rewaveStatus2+'.svg" alt="img"></div><span id="countID2'+waveID+'" class="rewave">'+rewave+'<div class="explain">リウェーブ</div></span></div>'+
	      //いいね
	      '<div id="heart'+waveID+'" class="icons" onclick="incrementHeartCount('+waveID+')"><div class="heart"><img width="20px" height="20px" src="image/'+heartStatus1+'.svg"><img class="image-b" height="20px" width="20px" src="image/'+heartStatus2+'.svg" alt="img"></div><span id="countID'+waveID+'" class="heart">'+heart+'<div class="explain">いいね</div></span></div>'+
	      //閲覧数
	      '<div class="icons"><div class="impression"><img width="25px" height="25px" src="image/impression.svg"><img width="25px" height="25px" src="image/impression1.svg" class="image-b"></div><span class="impression">'+views+'<div class="explain">視聴回数</div></span></div>'+
	      //…
	      '<div class="icons"><div class="impression ellipsis"><img width="20px" height="20px" src="image/ellipsis.svg"><img class="image-b" width="20px" height="20px" src="image/ellipsis1.svg"></div></div></div>'+
	      '</div>' +
	      '</div>' +
	      '<div class="hsp6p"></div>' +
	      '</div>'+
	      '</div>'+
	      '</div>'+
	      '</div>';
		  count++;
		  viewincrement(waveID);//フェッチするたびに閲覧数+1
		  loadfetchvalues();//フェッチするたびに変数追加
	    return { text: async () => content};//content変数をinfinite.jsへreturn;
    }
    else if(error != 0){
		// error変数が1の場合の処理
		let content = '<div id="post" class="newest">おすすめのコンテンツは以上です。</div>';
		loadfetchvalues();//変数追加
		return { text: async () => content};
	}
  } catch (error) {
	  let content = '<div id="post" class="newest">データの取得中にエラーが発生しました。</div>';
    console.error('データの取得中にエラーが発生しました', error);
    return { text: async () => content};
  }
};
//*----------------------------------------------------------*analysis()*----------------------------------------------------------*//
//呼び出されたらanalysisテーブルを返す
function analysis() {
    return new Promise(function (resolve, reject) {
        var x = document.querySelector('.userid');
        let text = x.textContent || x.innerText;
        let userid = text.split('@')[1];

        var dataToSend = { key1: 'analysis', key2: userid };
        $.ajax({
            url: "/HF21/servlet/asyncservlet",
            type: "POST",
            data: dataToSend,
            success: function (data) {
                if (data === "error") {
                    alert('該当するwaveポストは既に削除されています。');
                    reject('Error: Waveポストが存在しません');
                } else {
                    resolve(data);
                }
            },
            error: function () {
                alert('エラーが発生しました。');
                reject('Error: エラーが発生しました');
            }
        });
    });
}
//*----------------------------------------------------------*viewincrement()*----------------------------------------------------------*//
//呼び出された該当waveIDにviewを追加する
function viewincrement(wave_ID) {
    var dataToSend = { key1: 'viewincrement', key2: wave_ID };
    $.ajax({
        url: "/HF21/servlet/asyncservlet",
        type: "POST",
        data: dataToSend
    });
}
//*----------------------------------------------------------*ポスト詳細画面*----------------------------------------------------------*//
// ページ遷移先のJSPファイルのURL
let k = true;
var postElements;
let temp = new Array(5);
function loadfetchvalues() {
    // 親要素にクリックイベントを追加
    postElements = document.querySelectorAll('.U70U6FU73U74');
    // .U70U6FU73U74 クラスを持つ .post 要素にクリックイベントを追加
    postElements.forEach(function(postElement, index) {
	// クリックイベントを追加済みの要素かどうかを判定
    if (!postElement.classList.contains('JIhsoOsVnE')) {
        postElement.addEventListener('click', function(event) {
            // クリックされた要素が .hasamu クラスを持っていれば処理を実行
    		if(event.target.classList.contains('postindm')){
				window.location.href = "#";
			}
            if (!event.target.classList.contains('postindm') && !event.target.classList.contains('impression') && !event.target.classList.contains('image-b')
                && !event.target.classList.contains('heart') && !event.target.classList.contains('icons') && !event.target.classList.contains('rewave')
                && !event.target.classList.contains('maru') && !event.target.classList.contains('username') && !event.target.classList.contains('userid')
                && !event.target.classList.contains('timesago')) {
		                let temp = postElements[index].querySelector(".wr5TIPcMoO .kOI6nTrabP .vwSl7PQK7o .xyz .y");
		                let temp1 = postElements[index].querySelector(".z .userid").outerHTML.split("@");
		                let userID = temp1[1].split("</div>");
		                temp[0] = temp.querySelector(".hasamu .icons");
		                temp[1] = temp[0].outerHTML;
		                temp[2] = temp[1].split(" ");
		                temp[3] = temp[2][1].match(/id="([^"]+)"/);
		                temp[4] = temp[3][1].split("rewave");
		                console.log(userID[0]+temp[4][1]);
		                window.location.href = "/HF21/waves/"+userID[0]+"/"+temp[4][1];
            }
            event.stopPropagation();
        });
        // クリックイベントを追加済みの要素にクラスを追加
        postElement.classList.add('JIhsoOsVnE');
        }
    });
}//*----------------------------------------------------------*戻るメソッド*----------------------------------------------------------*//
