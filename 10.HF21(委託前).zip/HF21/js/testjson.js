function loadJsonData() {
  // fetchを使用してJSONデータを取得
  fetch('js/wave.json')
    .then(response => response.json())
    .then(jsonData => {
      // コンソールログでJSONデータを確認
      console.log('JSONデータ:', jsonData);
 
      // JSONデータを表示するHTMLを構築
      var htmlContent = '<h2>JSONデータの表示</h2>';
      for (var key in jsonData) {
        if (jsonData.hasOwnProperty(key)) {
          htmlContent += '<h3>' + key + '</h3>';
 
          // jsonData[key][1] が存在するか確認
          if (jsonData[key][1]) {
            htmlContent += '<ul>';
            for (var i = 0; i < jsonData[key][1].length; i++) {
              htmlContent += '<li>';
              for (var j = 0; j < jsonData[key][1][i].length; j++) {
                htmlContent += jsonData[key][1][i][j] + ': ';
              }
              htmlContent += '</li>';
            }
            htmlContent += '</ul>';
          } else {  
            htmlContent += '<p>No data available.</p>';
          }
        }
      }
 
      // HTML要素に表示
      document.getElementById('jsonDataDisplay').innerHTML = htmlContent;
    })
    .catch(error => console.error('ファイルの読み込み中にエラーが発生しました', error));
}