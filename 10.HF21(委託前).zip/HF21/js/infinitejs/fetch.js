let userdata = 0;
// loadjs関数 ＝  非同期関数
async function loadjson() {
  try {
    const response = await fetch('js/content1.json');
    const jsonData = await response.json();
    if(userdata < jsonData.length){
	    let username = jsonData[userdata].username;
	    let userid = jsonData[userdata].userid;
	    let usericon = jsonData[userdata].usericon;
	    let time = jsonData[userdata].time;
	    let maincontent = jsonData[userdata].maincontent;
	    let heart = jsonData[userdata].heart;
	    console.log(username);
	    console.log('JSONデータ:', jsonData);
	    userdata++;
	    let error = 0;
	    return { username, userid, usericon, time, maincontent, heart, error};
    }
    else{
		let error = 1;
		return{error}
	}
  } catch (error) {
    console.error('ファイルの読み込み中にエラーが発生しました', error);
    throw error;
  }
}

// fetchDummy関数  =  非同期関数
window.fetchdata = async url => {
  try {
    var jsonData = await loadjson();
    let error = jsonData.error;
    if (error == 0) {	
	    // error変数が0の場合の処理
	    let username = jsonData.username;			//ユーザー名取得
	    let userid = jsonData.userid;				//ユーザーid取得
	    let usericon = jsonData.usericon;			//ユーザーiconディレクトリ取得
	    let time = jsonData.time;					//発信時間取得
	    let maincontent = jsonData.maincontent;		//メインコンテンツ取得
	    let heart = jsonData.heart;					//いいね数取得
	    let content = 								//コンテンツ内容定義
	      '<div id="post">' +
	      '<div class="hsp12p"></div>' +
	      '<div class="xyz">' +
	      '<div class="picture"><img class="maru" src="'+ usericon +'" alt="picture"></div>' +
	      '<div class="y">' +
	      '<div class="z">' +
	      '<div class="username">' + username + '</div>' +
	      '<div class="userid">@'+ userid +'</div>' +
	      '<div class="timesago">·'+ time +'</div>' +
	      '</div>' +
	      '<div class="hsp3p"></div>' +
	      '<div class="maincontent">'+ maincontent +'</div>' +
	      '<div class="hsp3p"></div>' +
	      '<div class="hasamu"><div class="icons">💭</div><div class="icons"><img src="image/heart.png"></div><div class="icons">◯</div><div class="icons">□</div><div class="icons">…</div></div>' +
	      '</div>' +
	      '</div>' +
	      '<div class="hsp6p"></div>' +
	      '</div>';
	    return { text: async () => content};		//content変数をinfinite.jsへreturn;
    }
    else if(error != 0){
		// error変数が1の場合の処理
		let content = '<div id="post" class="newest">最新のコンテンツは以上です</div>';
		return { text: async () => content};
	}
  } catch (error) {
    console.error('データの取得中にエラーが発生しました', error);
    return { text: async () => '' };
  }
};