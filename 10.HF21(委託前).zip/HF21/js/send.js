// 変数を決定
var userid = "tosshi3333";
var waveid = "21";
// ページ遷移先のJSPファイルのURL
var url = "/HF21/waves/"+userid+"/"+waveid;

document.getElementById('send').addEventListener('click', function() {
window.location.href = url;
})