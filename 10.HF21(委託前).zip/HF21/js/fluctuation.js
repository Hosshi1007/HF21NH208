function incrementHeartCount(index) {
    // key１はいいねが押された判定、key2は押されたWaveID、key3は誰が押したかuserid
    var dataToSend = {key1: 'heart',key2: index,key3: meUjd};
    //数値を増加させる変数を用意
    var countID = "countID"+index;
    //数値を取得
    var countElement = document.getElementById(countID);
    //テキストからintに変換
    var currentCount = parseInt(countElement.textContent);
    // 数値を増加させる
    var newCount = currentCount + 1;
    var lowCount = currentCount - 1;
    $.ajax({
        url: "/HF21/servlet/asyncservlet", // サーブレットのパス
        type: "POST",
        data: dataToSend,  // 送信するデータ

        // Ajaxリクエストを使用してサーバーサイドの処理を呼び出す
        success: function(data) {
            // サーバーサイドでの処理が成功した場合のコールバック
            if(data==0){
			    let imageElement = document.getElementById('heart' + index).querySelector('img');
			    if (imageElement) {
			        imageElement.setAttribute('src', '/HF21/image/hearted.svg');
			    }
            	countElement.textContent = newCount;//DBのいいねフラグが０だった場合プラス１
            }
            else if(data==1){
				let imageElement = document.getElementById('heart' + index).querySelector('img');
			    if (imageElement) {
			        imageElement.setAttribute('src', '/HF21/image/heart.svg');
			    }
            	countElement.textContent = lowCount;//DBのいいねフラグ１だった場合マイナス１
            }
            else if(data=='null'){
				let imageElement = document.getElementById('heart' + index).querySelector('img');
			    if (imageElement) {
			        imageElement.setAttribute('src', '/HF21/image/hearted.svg');
			    }
            	countElement.textContent = newCount;//レコードがなかった場合プラス１
            }
            else if(data=="error"){//そもそもいいねorリウェーブしたポストがクリックした時点で存在しない場合
            	alert('該当するwaveポストは既に削除されています。');
            }
        },
        error: function() {
            // エラー時の処理
            alert('エラーが発生しました。');
        }
    })
}
function incrementRewaveCount(index) {
    // key１はいいねが押された判定、key2は押されたWaveID、key3は誰が押したかuserid
    var dataToSend = {key1: 'rewave',key2: index,key3: meUjd};
    //数値を増加させる変数を用意
    var countID = "countID2"+index;
    console.log(countID);
    //数値を取得
    var countElement = document.getElementById(countID);
    //テキストからintに変換
    var currentCount = parseInt(countElement.textContent);
    // 数値を増加させる
    var newCount = currentCount + 1;
    var lowCount = currentCount - 1;
    $.ajax({
        url: "/HF21/servlet/asyncservlet", // サーブレットのパス
        type: "POST",
        data: dataToSend,  // 送信するデータ

        // Ajaxリクエストを使用してサーバーサイドの処理を呼び出す
        success: function(data) {
            // サーバーサイドでの処理が成功した場合のコールバック
            if(data==0){
				let imageElement = document.getElementById('rewave' + index).querySelector('img');
			    if (imageElement) {
			        imageElement.setAttribute('src', '/HF21/image/rewaved.svg');
			    }
            	countElement.textContent = newCount;//DBのいいねフラグが０だった場合プラス１
            }
            else if(data==1){
				let imageElement = document.getElementById('rewave' + index).querySelector('img');
			    if (imageElement) {
			        imageElement.setAttribute('src', '/HF21/image/rewave.svg');
			    }
            	countElement.textContent = lowCount;//DBのいいねフラグ１だった場合マイナス１
            }
            else if(data=='null'){
				let imageElement = document.getElementById('rewave' + index).querySelector('img');
			    if (imageElement) {
			        imageElement.setAttribute('src', '/HF21/image/rewaved.svg');
			    }
            	countElement.textContent = newCount;//レコードがなかった場合プラス１
            }
            else if(data=="error"){//そもそもいいねorリウェーブしたポストがクリックした時点で存在しない場合
            	alert('該当するwaveポストは既に削除されています。');
            }
        },
        error: function() {
            // エラー時の処理
            alert('エラーが発生しました。');
        }
    })
}
//----------------*戻るボタン*--------------//
document.addEventListener('DOMContentLoaded', function() {
	var backButton = document.querySelector('.back');
	backButton.addEventListener('click', function() {
		var ref = document.referrer;             // リファラ情報を得る
		var hereHost = window.location.hostname; // 現在ページのホスト(ドメイン)名を得る
	 
		// ホスト名が含まれるか探す正規表現を作る(大文字・小文字を区別しない)
		var sStr = "^https?://" + hereHost;
		var rExp = new RegExp( sStr, "i" );
		 
		// リファラ文字列を判別
		if( ref.length == 0 ) {
		    // リファラなしの場合
		    window.location.href = '/HF21/home.jsp';
		}
		else if( ref.match( rExp ) ) {
		    window.history.back();
		}
		else {
		    window.location.href = '/HF21/home.jsp';
		}

    });
});