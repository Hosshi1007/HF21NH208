package wave;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns= {"/servlet/asyncservlet"})
public class asyncservlet extends HttpServlet{
	public void doPost(
		HttpServletRequest req,
		HttpServletResponse res
	)
	throws ServletException,IOException{

	req.setCharacterEncoding("UTF-8");
	res.setContentType("text/html;charset=UTF-8");

	boolean wave = false;
	ArrayList tbl = new ArrayList();
	ArrayList row = new ArrayList();
    String key1Value = req.getParameter("key1");
    String tense = "ed";//rewaveだった場合、edをつけるとrewaveedになるのでdだけにし、rewavedになるようにする
    int column_selector = 3;
    if(key1Value.equals("rewave")) {
    	tense = "d";
    	column_selector = 4;
    }
    else if(key1Value.equals("analysis")) {
    	String userid = req.getParameter("key2");
    	tbl = select_analysis(userid);
    	res.getWriter().write(tbl.toString());
    	return;
    }
    else if(key1Value.equals("viewincrement")) {
    	int waveID = Integer.parseInt(req.getParameter("key2"));
    	update_views(waveID);
    	return;
    }
    String key2Value = req.getParameter("key2");
    String key3Value = req.getParameter("key3");
	try {
		//Beanを呼び出してインスタンス化
		wave.wave_select_Beans select_Beans = new wave.wave_select_Beans();

		//プロパティのセット
		//テーブル
		select_Beans.setTable("t_wave");
		//条件
		select_Beans.setConditions("waveID= '" + key2Value + "'");
		//フィールド
		select_Beans.setFields("*");

		//Beanコール
		select_Beans.DBselect();

		//当該WAVEが存在するか確認
		if(select_Beans.getHit_flag()) {
			tbl = select_Beans.getTbl();
			row = (ArrayList)tbl.get(0);

			if(key2Value.equals((String)row.get(0))) {
				wave = true;
			}
		}
//		nユーザーがm要素をクリックしたらまずt_analysisテーブルでnユーザーとm要素で検索し、
//		該当しなかったらレコードを追加し、クリック履歴を１に設定し、
//		該当した場合はクリック履歴の中身を検索し、１だった場合０にし、
//		０だった場合は１に設定する
		//プロパティのセット
		if(wave){//当該WAVEが確認完了
		select_Beans.setTbl();
		//テーブル
		select_Beans.setTable("t_analysis");
		//条件
		select_Beans.setConditions("userID= '" + key3Value + "' AND waveID= '" + key2Value + "'");
		//フィールド
		select_Beans.setFields("*");

		//Beanコール
		select_Beans.DBselect();
		//analysisレコードが該当するか
		if(select_Beans.getHit_flag()) {
			tbl = select_Beans.getTbl();
			row = (ArrayList)tbl.get(0);
			//履歴が０の場合
			if("0".equals((String)row.get(column_selector))) {
				System.out.println("履歴１追加");
				wave.wave_update_bean update_Beans = new wave.wave_update_bean();
				//プロパティのセット
				//テーブル
				update_Beans.setTable("t_analysis");
				//条件
				update_Beans.setJyouken("userID= '" + key3Value + "' AND waveID= '" + key2Value + "'");
				//フィールド
				update_Beans.setFields(key1Value+tense+"="+ 1);

				//Beanコール

				update_Beans.DBupdate();
				res.getWriter().write(String.valueOf(0));
			}
			//履歴が１の場合
			else if("1".equals((String)row.get(column_selector))) {
				System.out.println("履歴０にする");
				wave.wave_update_bean update_Beans = new wave.wave_update_bean();
				//プロパティのセット
				//テーブル
				update_Beans.setTable("t_analysis");
				//条件
				update_Beans.setJyouken("userID= '" + key3Value + "' AND waveID= '" + key2Value + "'");
				//フィールド
				update_Beans.setFields(key1Value+tense+"="+ 0);

				//Beanコール
				update_Beans.DBupdate();
				res.getWriter().write(String.valueOf(1));
			}
		}
		else {//履歴が該当しない場合、新しいレコードを追加
			System.out.println("新レコードを追加");
			wave.wave_insert_bean insert_Beans = new wave.wave_insert_bean();
			//プロパティのセット
			//テーブル
			insert_Beans.setTable("t_analysis");
			//フィールド
			insert_Beans.setFields("userID,waveID,"+key1Value+tense);
			//変数の中身
			insert_Beans.setValues(key3Value+"',"+key2Value+",'"+1);

			//Beanコール
			insert_Beans.DBinsert();
			res.getWriter().write(String.valueOf("null"));
		}
		wave.wave_update_bean update_Beans = new wave.wave_update_bean();
		//プロパティのセット
		//テーブル
		//テーブル
		update_Beans.setTable("t_wave");
		//条件
		update_Beans.setJyouken("waveID= " + key2Value);
		//フィールド
		update_Beans.setFields(key1Value+"  = COALESCE((SELECT SUM("+key1Value+tense+") FROM t_analysis WHERE t_wave.waveID = t_analysis.waveID AND t_wave.waveID = "+key2Value+"), 0) ");

		//Beanコール
		update_Beans.DBupdate();
		}
		else {//当該レコーとがなかった場合
			res.getWriter().write(String.valueOf("error"));
		}

	}
	catch(Exception ex) {
		PrintWriter out;
		req.setCharacterEncoding("UTF-8");
		res.setContentType("text/html;charset=UTF-8");
		out = res.getWriter();
		ex.printStackTrace(out);
	}
}
    public ArrayList select_analysis(String userID) {
    	ArrayList tbl = new ArrayList();
    	wave.wave_select_Beans select_Beans = new wave.wave_select_Beans();
		//プロパティのセット
		//テーブル
		select_Beans.setTable("t_analysis");
		//条件
		select_Beans.setConditions("userID= '" + userID + "'");
		//フィールド waveID | hearted | rewaved | clicked
		select_Beans.setFields("waveID,hearted,rewaved,clicked");

		//Beanコール
		select_Beans.DBselect();
		tbl = select_Beans.getTbl();
        return tbl;
    }
    public void update_views(int waveID) {
    	ArrayList tbl = new ArrayList();
    	wave.wave_update_bean update_Beans = new wave.wave_update_bean();
		//プロパティのセット
		//テーブル
    	update_Beans.setTable("t_wave");
		//条件
    	update_Beans.setJyouken("waveID =  " + waveID);
		//フィールド waveID | hearted | rewaved | clicked
    	update_Beans.setFields("views =  views + 1");

		//Beanコール
    	update_Beans.DBupdate();
        return;
    }
}