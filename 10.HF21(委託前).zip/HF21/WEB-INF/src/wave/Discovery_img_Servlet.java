package wave;

import java.io.File;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class Discovery_Servlet {
	
	public ArrayList get_allwave_oneuser(String userID) {
		try {
			//Beanを呼び出してインスタンス化
			wave.Discovery_Beans Discovery = new wave.Discovery_Beans();

			//プロパティのセット
			//テーブル
			Discovery.setTable("t_wave");
			//フィールド
			Discovery.setFields("*");
			//条件
			Discovery.setConditions("userID= '" + userID + "'");
			//日付の新しい順
			Discovery.setSort("order by posttime desc");
			//Beanコール
			Discovery.DBselect();
			//結果を取得してreturnする
			return Discovery.getTbl();
		}
		catch(Exception ex) {
			System.out.println(ex);
			return null;
		}
	}
	
	public void get_wave_manyuser() {
		//一旦全部のwaveを取得しますｗｗ
		//後でどのwaveを取得すべきか選別してからselectするやつを別に作るか？
		try {
			//Beanを呼び出してインスタンス化
			wave.Discovery_Beans Discovery = new wave.Discovery_Beans();
	
			//プロパティのセット
			//テーブル
			Discovery.setTable("t_wave as w join t_user as u on w.userID = u.userID");
			//条件　※条件要らないから無理やり
			Discovery.setConditions("'A' = 'A'");
			//フィールド
			//0:waveID 1:userID 2:user_name 3:user_img 4:wave_contents
			//5:imgID1 6:imgID2 7:imgID3 8:imgID4 9:positime
			Discovery.setFields("w.waveID,w.userID,u.user_name,u.user_img,w.wave_contents,w.imgID1,w.imgID2,w.imgID3,w.imgID4,w.posttime");
			//日付の新しい順
			Discovery.setSort("order by posttime desc");
			//Beanコール
			Discovery.DBselect();
	
			//結果をjsonファイルに出力する為の作業を開始
	
			//結果を取得
			ArrayList wavetbl = Discovery.getTbl();
			ArrayList userrow = new ArrayList();
	
	
			// Javaオブジェクトに値をセット
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
	
			ArrayNode jsonArray = objectMapper.createArrayNode();

			System.out.println("wavetbl.size()＝" + wavetbl.size());
			
			for (int i = 0; i < wavetbl.size(); i++) {
				userrow = (ArrayList) wavetbl.get(i);
				System.out.println("userrow.get(2).toString()＝" + userrow.get(2).toString());
				ObjectNode objectNode = createObjectNode(Integer.parseInt(userrow.get(0).toString()));
				jsonArray.add(objectNode);
			}
	
	
			// ファイルパスを指定
			String filePath = "C:\\java_workspace\\HF21\\Discovery.json";
			// ファイルに書き込む
			objectMapper.writeValue(new File(filePath), jsonArray);
		}
		catch(Exception ex) {
			System.out.println(ex);
		}
	}

	// 各ObjectNodeを生成するメソッド
	private static ObjectNode createObjectNode(int index) {
		try {
			wave.Discovery_Beans Discovery = new wave.Discovery_Beans();
			Discovery.setTable("t_wave as w join t_user as u on w.userID = u.userID");
			Discovery.setConditions("w.waveID = '" + index + "'");
			Discovery.setFields("w.waveID,w.userID,u.user_name,u.user_img,w.wave_contents,w.imgID1,w.imgID2,w.imgID3,w.imgID4,w.posttime,w.heart,w.rewave,w.views");
			Discovery.DBselect();
			ArrayList wavetbl = Discovery.getTbl();
			ArrayList userrow = (ArrayList) wavetbl.get(0);
			
			ObjectMapper objectMapper = new ObjectMapper();
			ObjectNode objectNode = objectMapper.createObjectNode();
			
			objectNode.put("waveID", Integer.parseInt(userrow.get(0).toString()));
			objectNode.put("username", userrow.get(2).toString());
			objectNode.put("userid", userrow.get(1).toString());
			objectNode.put("user_img", userrow.get(3).toString());
			objectNode.put("time", 1); // Assuming "time" is hardcoded to 1 in your example
			objectNode.put("maincontent", userrow.get(4).toString());
			objectNode.put("imgID1", userrow.get(5).toString());
			objectNode.put("imgID2", userrow.get(6).toString());
			objectNode.put("imgID3", userrow.get(7).toString());
			objectNode.put("imgID4", userrow.get(8).toString());
			objectNode.put("posttime", userrow.get(9).toString());
			objectNode.put("heart", userrow.get(10).toString());
			objectNode.put("rewave", userrow.get(11).toString());
			objectNode.put("views", userrow.get(12).toString());
			objectNode.put("reply", "null");
			
			wavetbl = Discovery.getTbl();
			userrow = (ArrayList) wavetbl.get(0);
			
			// Return the constructed objectNode
			return objectNode;
		}
		catch (Exception ex) {
			System.out.println(ex);
			return null;
		}
	}
}