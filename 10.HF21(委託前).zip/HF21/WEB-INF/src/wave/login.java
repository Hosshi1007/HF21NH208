package wave;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns= {"/servlet/login"})
public class login extends HttpServlet{
	public void doPost(
		HttpServletRequest req,
		HttpServletResponse res
	)
	throws ServletException,IOException{

		req.setCharacterEncoding("UTF-8");
		res.setContentType("text/html;charset=UTF-8");

		//webブラウザのFormページからパラメータを取得
		String userIDStr = req.getParameter("userID");
		String passwordStr = req.getParameter("password");

		boolean login = false;
		ArrayList tbl = new ArrayList();
		ArrayList row = new ArrayList();
		try {
			//Beanを呼び出してインスタンス化
			wave.Discovery_Beans Discovery = new wave.Discovery_Beans();
			//プロパティのセット
			//フィールド
			Discovery.setFields("*");
			//テーブル
			Discovery.setTable("t_user");
			//条件
			Discovery.setConditions("userID= '" + userIDStr + "'");
			//Beanコール
			Discovery.DBselect();
			//パスワードが一致しているか確認
			if(Discovery.getHit_flag()) {//ユーザ名が存在するか確認
				tbl = Discovery.getTbl();
				row = (ArrayList)tbl.get(0);

				if(passwordStr.equals((String)row.get(2))) {
					login = true;
				}
			}
			
			if(login){//ログイン成功

				tbl = select_analysis(userIDStr);

				//Beanコール
				Discovery.DBselect();
				HttpSession session = req.getSession();

				//有効時間(10分)
				session.setMaxInactiveInterval(6000);

				//セッションにバインド
				session.setAttribute("session_userID",(String)row.get(0));//ログインID
				session.setAttribute("session_username",(String)row.get(1));//ユーザー名
				session.setAttribute("session_usericon",(String)row.get(4));//ユーザーアイコン
				session.setAttribute("analysis_tbl",(ArrayList)tbl);
				System.out.println((String)row.get(4)+"これがユーザーアイコンや！！");
				System.out.println(tbl);

				//メイン画面に遷移
				res.sendRedirect("/HF21/Discovery.jsp");//適当に命名しているので決まり次第変更お願いします


			}else{//ユーザ名かパスワードが間違っている場合
				//JSPコール
				req.setAttribute("userID", userIDStr);
				ServletContext sc = getServletContext();
				sc.getRequestDispatcher("/login.jsp").forward(req, res);
			}
		}
		catch(Exception ex) {
			PrintWriter out;
			req.setCharacterEncoding("UTF-8");
			res.setContentType("text/html;charset=UTF-8");
			out = res.getWriter();
			ex.printStackTrace(out);
		}
	}
	
	
    public ArrayList select_analysis(String userID) {
    	ArrayList tbl = new ArrayList();
    	wave.Discovery_Beans Discovery = new wave.Discovery_Beans();
		//プロパティのセット
		//テーブル
    	Discovery.setTable("t_analysis");
		//条件
    	Discovery.setConditions("userID= '" + userID + "'");
		//フィールド waveID | hearted | rewaved | clicked
    	Discovery.setFields("waveID,hearted,rewaved,clicked");

		//Beanコール
    	Discovery.DBselect();
		tbl = Discovery.getTbl();
        return tbl;
    }
}